import sqlite3
from sqlite3 import Error

con = sqlite3.connect('tiendaBD.db')
cursorObj = con.cursor()
print('---- Bienvenido a la BBDD TIENDA tabla CLIENTE ---- ')
def crear(con):
    cursorObj.execute("CREATE TABLE cliente(id integer PRIMARY KEY, nombre text, edad integer, ciudad text)")
    con.commit()
    print("Tabla creada")
#crear(con)
def insertar(con, valores=(0, '', 0, '')):
    cursorObj.execute('INSERT INTO cliente (id,nombre,edad,ciudad)VALUES(?, ?, ?, ?)', (valores))
    con.commit()

def select():
    cursorObj.execute('SELECT * FROM cliente')
    registros = cursorObj.fetchall()
    for fila in registros:
        print(fila)

def borrar(con, id):
    cursorObj.execute('Delete from cliente where id =?',(id))
    con.commit()

def actualizar(con):
    print('¿Qué cliente desea modificar?')
    select()
    print('Indique su id')
    id = input()
    print("1.Cambiar nombre")
    print("2.Cambiar edad")
    print("3.Cambiar ciudad")
    opcion = input()
    if (opcion == '1'):
        print('Nuevo nombre: ')
        valor = input()
        cursorObj.execute('Update cliente set nombre=? where id=?', (valor, id))

    elif (opcion == '2'):
        print('Nueva edad: ')
        valor = input()
        cursorObj.execute('Update cliente set edad=? where id=?', (valor, id))

    elif (opcion == '3'):
        print('Nueva ciudad: ')
        valor = input()
        cursorObj.execute('Update cliente set ciudad=? where id=?', (valor, id))
    con.commit()


def menu():
    programa = True
    while (programa):

        print("1. Mostrar")
        print("2. Insertar")
        print("3. Actualizar")
        print("4. Borrar")
        print("5. Salir")
        opcion = input()
        if (opcion == '1'):
            select()
        elif (opcion == '2'):
            print("id: ")
            id = input()
            print("nombre: ")
            nombre = input()
            print("edad: ")
            edad = input()
            print("ciudad: ")
            ciudad = input()
            insertar(con, valores=(id, nombre, edad, ciudad))
        elif (opcion == '3'):
            actualizar(con)
        elif (opcion == '4'):
            select()
            print('¿Qué cliente desea eliminar?(Indique su id)')
            id = input()
            borrar(con, id)
        elif (opcion == '5'):
            print('CERRANDO PROGRAMA')
            programa = False


menu()
